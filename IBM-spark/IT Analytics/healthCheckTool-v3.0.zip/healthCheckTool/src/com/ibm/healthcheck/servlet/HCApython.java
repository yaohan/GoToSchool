package com.ibm.healthcheck.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Request;

@WebServlet("/HCApython")
public class HCApython extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String basePath = getServletContext().getRealPath("/") + File.separator + "MyHCA";
		
		System.out.println("进入测试方法");
		// TODO Auto-generated method stub		
		/**
		 * 使用java Process直接执行python脚本
		 * 
		 * @author dypdong@cn.ibm.com
		 * 
		 */
		//需传入的参数
		String execPath = basePath +File.separator+"HealthCheck";
	    String uploadPath = basePath + File.separator + "uploadFiles" + File.separator + req.getAttribute("fileName");
        String generatePath = basePath +File.separator+"HealthCheck" + File.separator + "generatedFiles"+File.separator;
		File generateDir = new File(generatePath);
		if (!generateDir.exists()) {
			generateDir.mkdir();
		}
		//设置命令行传入参数
        String cmd = "python MyHCA.py "+ uploadPath+" "+ generatePath;
        System.out.println(cmd);
        //在execPath路径下执行cmd命令
        Process proc = Runtime.getRuntime().exec(cmd,null,new File(execPath));  
		
        System.out.println("＋＋＋＋＋执行中＋＋＋＋＋");
	    
        //获取cmd输出的内容
		BufferedReader input = new BufferedReader(new InputStreamReader(proc.getInputStream()));  		   
        String line = null;  
        String reportFile = "";
        String htmlFileName = "";
        while ((line = input.readLine()) != null) {  
            System.out.println(line); 
            //获得python生成真实的html文件名
            if (line.contains("ReportFile")){
            	System.out.println("line:"+line); 
            	reportFile = "ReportFile_"+req.getAttribute("fileName");
            	//获取当前工程在磁盘的真实路径
            	String reportFilePath =generatePath + reportFile + File.separator;
				System.out.println(reportFilePath);
				File file = new File(reportFilePath);
				File[] tempList = file.listFiles();
				for (int i = 0; i < tempList.length; i++) {
					if (tempList[i].getName().contains(".html")) {
						htmlFileName = tempList[i].getName();
						System.out.println(htmlFileName);
						break;
					}
				}
			}
        }  
        int exitVal = 0;
		try {
			exitVal = proc.waitFor();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  
        System.out.println("Exited with error code " + exitVal);
        if(exitVal == 0 && !reportFile.equals("")){
        	System.out.println("python run success ");
            String htmlFilePath ="/healthCheckTool/MyHCA/HealthCheck/generatedFiles/" + reportFile + "/" + htmlFileName;
        	resp.getWriter().print(htmlFilePath);
        }else{
        	//failed
        	resp.getWriter().print("error"); 
        }
        
	}
	
}
