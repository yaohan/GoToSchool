package com.ibm.healthcheck.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.List;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
 

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/CompareServlet")
public class CompareServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
     
    // 上传文件存储目录
    private static final String UPLOAD_DIRECTORY = "MyHCA" + File.separator + "uploadFiles";
 
    // 上传配置
    private static final int MEMORY_THRESHOLD   = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE      = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE   = 1024 * 1024 * 50; // 50MB
    
	private String healthCheck(String fileName,String basePath) {
		System.out.println("healthCheck start");
		try {
	    	
	    	//执行命令的路径
			String execPath = basePath+File.separator+"HealthCheck";
			//处理的文件路径
		    String uploadPath = basePath + File.separator + "uploadFiles" + File.separator + fileName;
		    //生成结果的路径
	        String generatePath = basePath+File.separator+"HealthCheck" + File.separator + "generatedFiles"+File.separator;
	        File generateDir = new File(generatePath);
			if (!generateDir.exists()) {
				generateDir.mkdir();
			}
	        //命令
	        String cmd = "python MyHCA.py "+ uploadPath+" "+ generatePath;
	        //在execPath路径下执行cmd命令
	        Process proc = Runtime.getRuntime().exec(cmd,null,new File(execPath));
	        //获取cmd输出的内容
			BufferedReader input = new BufferedReader(new InputStreamReader(proc.getInputStream()));  		   
	        String line = null;
	        String reportFile = "";
	        while ((line = input.readLine()) != null) {  
	            System.out.println(line);
	          //获得python生成真实的html文件名
	            if (line.contains("ReportFile")){ 
	            	reportFile = "ReportFile_"+fileName;
				}
	        }  
	        int exitVal = 0;
			try {
				
				exitVal = proc.waitFor();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}  
	        System.out.println("Exited with error code " + exitVal);
	        if(exitVal == 0 &&!reportFile.equals("")){
	        	return generatePath+"ReportFile_"+fileName+File.separator+"RawData"+File.separator;
	        }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    }
 
    /**
     * 上传数据及保存文件
     */
    protected void doPost(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		// 检测是否为多媒体上传
		if (!ServletFileUpload.isMultipartContent(request)) {
		    // 如果不是则停止
		    PrintWriter writer = response.getWriter();
		    writer.println("Error: 表单必须包含 enctype=multipart/form-data");
		    writer.flush();
		    return;
		}
 
        // 配置上传参数
        DiskFileItemFactory factory = new DiskFileItemFactory();
        // 设置内存临界值 - 超过后将产生临时文件并存储于临时目录中
        factory.setSizeThreshold(MEMORY_THRESHOLD);
        // 设置临时存储目录
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
 
        ServletFileUpload upload = new ServletFileUpload(factory);
         
        // 设置最大文件上传值
        upload.setFileSizeMax(MAX_FILE_SIZE);
         
        // 设置最大请求值 (包含文件和表单数据)
        upload.setSizeMax(MAX_REQUEST_SIZE);
        
        // 中文处理
        upload.setHeaderEncoding("UTF-8"); 

        // 构造临时路径来存储上传的文件
        // 这个路径相对当前应用的目录
        String uploadPath = request.getSession().getServletContext().getRealPath("/") + File.separator
				+ UPLOAD_DIRECTORY;	
         	
        // 如果目录不存在则创建
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }
        String firstName = null,secondName=null;
        try {
            // 解析请求的内容提取文件数据
            @SuppressWarnings("unchecked")
            List<FileItem> formItems = upload.parseRequest(request);
            System.out.println(formItems);
        	String filePath = uploadPath;
            if (formItems != null && formItems.size() > 0) {
                // 迭代表单数据
                for (FileItem item : formItems) {
                    // 处理不在表单中的字段
                    if (!item.isFormField()) {
                        String fileName = new File(item.getName()).getName();
                        System.out.println("filedName:"+item.getFieldName());
                        if(item.getFieldName().equals("firstFile")) {
                        	firstName = fileName;
                        }else if(item.getFieldName().equals("secondFile")) {
                        	secondName = fileName;
                        }
                    	String theFilePath = filePath + File.separator + fileName;
                        File storeFile = new File(theFilePath);
                        // 在控制台输出文件的上传路径
                        System.out.println(theFilePath);
                        // 保存文件到硬盘
                        item.write(storeFile);
                        request.setAttribute("message",
                            "文件上传成功!");
                    }
                }
            }
            String basePath = getServletContext().getRealPath("/") + File.separator + "MyHCA";
            
        	if(firstName != null && secondName != null) {
        		try {
        			//文件1生成rawData路径
                	String filePath1 = healthCheck(firstName,basePath);
        			//文件2生成rawData路径
                	String filePath2 = healthCheck(secondName,basePath);
                	String generateFile = getServletContext().getRealPath("/") + File.separator + "MyHCA" + File.separator+"Compare"+File.separator+"generatedFiles"+File.separator;
                	File generateFileDir = new File(generateFile);
        			if (!generateFileDir.exists()) {
        				generateFileDir.mkdir();
        			}
                	//生成文件夹路径
                	String generatedPath = generateFile+"ReportFile_compare_"+firstName+"_"+secondName;
                	File generateDir = new File(generatedPath);
        			if (!generateDir.exists()) {
        				generateDir.mkdir();
        			}
                	//生成命令
                	String cmd = "python compare.py "+ filePath1+" "+filePath2+" "+generatedPath;
                	System.out.println("cmd:"+cmd);
                	//执行路径
                	String execPath = getServletContext().getRealPath("/")+File.separator+"MyHCA"+File.separator+"Compare"+File.separator;
                	System.out.println("execPath:"+execPath);
                	//执行
                	Process pr = Runtime.getRuntime().exec(cmd,null, new File(execPath));
                	BufferedReader in = new BufferedReader(new InputStreamReader(pr.getInputStream()));
                    String line;
                    while((line =in.readLine())!=null){
                        System.out.println(line);
                    }
                    in.close();
                    pr.waitFor();
                    System.out.println("end");
                    String generateFilePath = getServletContext().getRealPath("/")+File.separator+"MyHCA"+File.separator+"Compare"+File.separator+"generatedFiles"+File.separator+"ReportFile_compare_"+firstName+"_"+secondName;
                    File htmlFile = new File(generateFilePath);
                    if(htmlFile.exists()) {
                        String htmlFilePath ="/healthCheckTool/MyHCA/Compare/generatedFiles/ReportFile_compare_"+firstName+"_"+secondName+"/ReportFile_compare_sorted.html";
                    	response.getWriter().print(htmlFilePath);
                    }else {
                    	response.getWriter().print("error");
                    }
                    
                    	
                } catch (IOException e) {
                	System.out.println(e);
                    e.printStackTrace();
                } catch (InterruptedException e) {
                	System.out.println(e);
                    e.printStackTrace();
                }
        	}
        } catch (Exception ex) {
        	response.getWriter().print("error");
//        	System.out.println(ex);
//            request.setAttribute("message",
//                    "错误信息: " + ex.getMessage());
        }
    }
}